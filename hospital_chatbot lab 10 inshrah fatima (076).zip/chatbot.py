import random

def get_response(user_input):
    text = user_input.lower()

    if "emergency" in text or "ambulance" in text:
        return "🚑 Emergency services are available 24/7. Call 1122 for immediate help."

    elif "room" in text or "availability" in text:
        responses = [
            "🏥 General rooms are available. ICU is currently limited.",
            "🏥 Some private rooms are available. Please contact reception.",
            "🏥 ICU beds are almost full. General ward has space."
        ]
        return random.choice(responses)

    elif "visiting" in text or "hours" in text:
        return "🕒 Visiting hours are from 10 AM to 8 PM daily."

    elif "doctor" in text:
        return "👨‍⚕️ Doctors are available from 9 AM to 5 PM. Emergency doctors are available 24/7."

    elif "hello" in text or "hi" in text:
        return "Hello! How can I assist you with hospital information?"

    else:
        return "I'm sorry, I didn't understand that. Please ask about emergency services, rooms, or visiting hours."
