# Hospital Information Chatbot (Flask + NLP)

## Features
- Emergency services info
- Room availability
- Visiting hours
- Doctor availability

## Run Project
1. Install requirements:
   pip install -r requirements.txt

2. Run:
   python app.py

3. Open:
   http://127.0.0.1:5000/
