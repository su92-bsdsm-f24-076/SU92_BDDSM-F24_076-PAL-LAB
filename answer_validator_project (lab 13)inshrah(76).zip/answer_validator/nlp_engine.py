"""
nlp_engine.py — Core NLP Processing Module
============================================
Techniques:
  1. Text Preprocessing  → lowercase, tokenize, remove stopwords, lemmatize
  2. TF-IDF Similarity   → sklearn TfidfVectorizer + cosine_similarity
  3. Keyword Coverage    → checks how many expected keywords student used
  4. Length Penalty      → penalizes extremely short answers
  5. Grade Assignment    → maps final score to letter grade + feedback
"""

import re
import math
from collections import Counter


# ──────────────────────────────────────────────
# Built-in stopwords (no NLTK download needed)
# ──────────────────────────────────────────────
STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "are", "was", "were", "be", "been",
    "being", "have", "has", "had", "do", "does", "did", "will", "would",
    "could", "should", "may", "might", "shall", "can", "it", "its", "that",
    "this", "these", "those", "i", "we", "you", "he", "she", "they", "them",
    "their", "our", "your", "his", "her", "as", "if", "when", "while",
    "which", "who", "whom", "what", "where", "how", "not", "no", "also",
    "such", "each", "any", "all", "both", "more", "most", "other", "some",
    "into", "through", "during", "than", "then", "so", "about", "up",
    "out", "just", "because", "used", "use", "using"
}

# Simple lemma rules (suffix-based)
LEMMA_RULES = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("ising", "ise"), ("izing", "ize"), ("ising", "ise"),
    ("nesses", "ness"), ("ments", "ment"), ("ities", "ity"), ("ives", "ive"),
    ("ables", "able"), ("ation", "ate"), ("ations", "ate"),
    ("nesses", ""), ("ment", ""), ("ness", ""), ("ity", ""),
    ("ing", ""), ("edly", ""), ("edly", ""), ("ingly", ""),
    ("ful", ""), ("ous", ""), ("ive", ""), ("ize", ""),
    ("ers", ""), ("ied", "y"), ("ies", "y"), ("ed", ""), ("es", ""), ("s", ""),
]


def simple_lemmatize(word: str) -> str:
    """Apply suffix-stripping lemmatization."""
    if len(word) <= 3:
        return word
    for suffix, replacement in LEMMA_RULES:
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            return word[: len(word) - len(suffix)] + replacement
    return word


def preprocess(text: str) -> list[str]:
    """
    Pipeline:
      lowercase → remove punctuation → tokenize → remove stopwords → lemmatize
    """
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = text.split()
    tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 2]
    tokens = [simple_lemmatize(t) for t in tokens]
    return tokens


# ──────────────────────────────────────────────
# TF-IDF from scratch
# ──────────────────────────────────────────────

def compute_tf(tokens: list[str]) -> dict:
    counts = Counter(tokens)
    total = len(tokens) if tokens else 1
    return {word: count / total for word, count in counts.items()}


def compute_tfidf_vector(tokens: list[str], idf: dict) -> dict:
    tf = compute_tf(tokens)
    return {word: tf_val * idf.get(word, 1.0) for word, tf_val in tf.items()}


def build_idf(docs: list[list[str]]) -> dict:
    N = len(docs)
    all_words = set(w for doc in docs for w in doc)
    idf = {}
    for word in all_words:
        df = sum(1 for doc in docs if word in doc)
        idf[word] = math.log((N + 1) / (df + 1)) + 1
    return idf


def cosine_similarity(vec1: dict, vec2: dict) -> float:
    common = set(vec1.keys()) & set(vec2.keys())
    if not common:
        return 0.0
    dot = sum(vec1[w] * vec2[w] for w in common)
    mag1 = math.sqrt(sum(v ** 2 for v in vec1.values()))
    mag2 = math.sqrt(sum(v ** 2 for v in vec2.values()))
    if mag1 == 0 or mag2 == 0:
        return 0.0
    return dot / (mag1 * mag2)


# ──────────────────────────────────────────────
# Main Validator Class
# ──────────────────────────────────────────────

class AnswerValidator:
    def validate(
        self,
        student_answer: str,
        model_answer: str,
        keywords: list[str],
        max_marks: int = 10,
    ) -> dict:

        # --- Step 1: Preprocess ---
        student_tokens = preprocess(student_answer)
        model_tokens = preprocess(model_answer)

        if not student_tokens:
            return self._empty_result(max_marks)

        # --- Step 2: TF-IDF Cosine Similarity ---
        idf = build_idf([student_tokens, model_tokens])
        student_vec = compute_tfidf_vector(student_tokens, idf)
        model_vec = compute_tfidf_vector(model_tokens, idf)
        semantic_score = cosine_similarity(student_vec, model_vec)  # 0–1

        # --- Step 3: Keyword Coverage ---
        student_text_lower = student_answer.lower()
        keywords_found = [kw for kw in keywords if kw.lower() in student_text_lower]
        keyword_score = len(keywords_found) / len(keywords) if keywords else 0.5

        # --- Step 4: Word Overlap (Jaccard) ---
        student_set = set(student_tokens)
        model_set = set(model_tokens)
        if student_set | model_set:
            overlap_score = len(student_set & model_set) / len(student_set | model_set)
        else:
            overlap_score = 0.0

        # --- Step 5: Length Penalty ---
        model_word_count = len(model_answer.split())
        student_word_count = len(student_answer.split())
        length_ratio = min(student_word_count / max(model_word_count * 0.3, 1), 1.0)
        length_penalty = 1.0 if length_ratio >= 1.0 else (0.7 + 0.3 * length_ratio)

        # --- Step 6: Composite Score ---
        # Weights: semantic=50%, keyword=30%, overlap=20%
        raw_score = (
            0.50 * semantic_score +
            0.30 * keyword_score +
            0.20 * overlap_score
        ) * length_penalty

        raw_score = min(max(raw_score, 0.0), 1.0)
        marks_obtained = round(raw_score * max_marks, 1)

        # --- Step 7: Grade & Feedback ---
        grade, feedback, color = self._grade(raw_score, keywords_found, keywords)

        # --- Step 8: Missing keywords ---
        missing_keywords = [kw for kw in keywords if kw.lower() not in student_text_lower]

        return {
            "marks_obtained": marks_obtained,
            "max_marks": max_marks,
            "percentage": round(raw_score * 100, 1),
            "grade": grade,
            "grade_color": color,
            "feedback": feedback,
            "breakdown": {
                "semantic_similarity": round(semantic_score * 100, 1),
                "keyword_coverage": round(keyword_score * 100, 1),
                "word_overlap": round(overlap_score * 100, 1),
                "length_adequacy": round(length_penalty * 100, 1),
            },
            "keywords_found": keywords_found,
            "keywords_missing": missing_keywords,
            "student_word_count": student_word_count,
            "model_word_count": model_word_count,
        }

    def _grade(self, score: float, found: list, all_kw: list):
        pct = score * 100
        missing_critical = len(all_kw) - len(found)

        if pct >= 85:
            return "A+", "Excellent! Comprehensive and accurate answer covering all key concepts.", "#10b981"
        elif pct >= 75:
            return "A", "Very good answer. Most concepts covered correctly.", "#22c55e"
        elif pct >= 65:
            return "B", "Good attempt. A few important points are missing or unclear.", "#84cc16"
        elif pct >= 50:
            return "C", "Average answer. Several key concepts are missing. Review the topic.", "#f59e0b"
        elif pct >= 35:
            return "D", "Below average. Major concepts are absent. Study the model answer carefully.", "#f97316"
        else:
            return "F", "Insufficient answer. Please study the topic thoroughly and retry.", "#ef4444"

    def _empty_result(self, max_marks):
        return {
            "marks_obtained": 0,
            "max_marks": max_marks,
            "percentage": 0,
            "grade": "F",
            "grade_color": "#ef4444",
            "feedback": "No meaningful content detected in the answer.",
            "breakdown": {
                "semantic_similarity": 0,
                "keyword_coverage": 0,
                "word_overlap": 0,
                "length_adequacy": 0,
            },
            "keywords_found": [],
            "keywords_missing": [],
            "student_word_count": 0,
            "model_word_count": 0,
        }
