# 🧠 Answer Validator — NLP + Flask Project

## Overview
An intelligent answer validation system that uses NLP techniques to compare
student answers with model answers and assign marks automatically.

---

## 📁 Project Structure

```
answer_validator/
│
├── app.py              ← Flask web server + routes
├── nlp_engine.py       ← Core NLP logic (TF-IDF, Cosine Similarity, etc.)
├── requirements.txt    ← Python dependencies
├── README.md           ← This file
│
└── templates/
    └── index.html      ← Frontend UI (dark-themed, responsive)
```

---

## 🔬 NLP Techniques Used

| Technique | Purpose | Weight |
|-----------|---------|--------|
| TF-IDF Vectorization | Convert text to numeric vectors | — |
| Cosine Similarity | Measure semantic similarity | 50% |
| Keyword Coverage | Check technical term usage | 30% |
| Jaccard Overlap | Word-set intersection ratio | 20% |
| Length Penalty | Penalize too-short answers | × multiplier |
| Lemmatization | Normalize word forms | preprocessing |
| Stopword Removal | Remove noise words | preprocessing |

---

## 🚀 How to Run

### Step 1: Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Run Flask server
```bash
python app.py
```

### Step 3: Open browser
```
http://localhost:5000
```

---

## 🌐 API Endpoints

### POST /validate
Validate against a predefined question.
```json
Request:
{
  "question_id": 1,
  "student_answer": "IPv6 is a 128-bit addressing protocol..."
}

Response:
{
  "marks_obtained": 8.5,
  "max_marks": 10,
  "percentage": 85.0,
  "grade": "A",
  "feedback": "Very good answer...",
  "breakdown": {
    "semantic_similarity": 82.3,
    "keyword_coverage": 90.0,
    "word_overlap": 65.4,
    "length_adequacy": 100.0
  },
  "keywords_found": ["128-bit", "IPv4"],
  "keywords_missing": ["340 undecillion"]
}
```

### POST /custom_validate
Validate with your own model answer.
```json
Request:
{
  "student_answer": "...",
  "model_answer": "...",
  "keywords": "TCP, routing, OSI",
  "max_marks": 10
}
```

---

## 📊 Scoring Formula

```
Score = (TF-IDF_Cosine × 0.50) +
        (Keyword_Coverage × 0.30) +
        (Jaccard_Overlap × 0.20)
        × Length_Penalty

Final_Marks = Score × Max_Marks
```

## 🏆 Grading Scale

| Grade | Percentage | Feedback |
|-------|-----------|---------|
| A+    | ≥ 85%    | Excellent |
| A     | ≥ 75%    | Very Good |
| B     | ≥ 65%    | Good |
| C     | ≥ 50%    | Average |
| D     | ≥ 35%    | Below Average |
| F     | < 35%    | Insufficient |

---

## 👨‍💻 Tech Stack
- **Backend:** Python 3.10+, Flask
- **NLP:** Custom TF-IDF engine (no external NLP libs required)
- **Frontend:** Vanilla HTML/CSS/JS (no frameworks)
- **Optional:** NLTK (better tokenization), scikit-learn (TF-IDF), sentence-transformers (SBERT)
