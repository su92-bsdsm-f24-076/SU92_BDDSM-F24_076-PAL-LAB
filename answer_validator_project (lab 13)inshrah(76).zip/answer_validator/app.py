"""
Answer Validator - NLP + Flask Project
----------------------------------------
NLP Techniques Used:
  - TF-IDF Vectorization
  - Cosine Similarity
  - NLTK: Tokenization, Stopword Removal, Lemmatization
  - Keyword Overlap Scoring
  - Sentence-BERT (optional, if installed)
"""

from flask import Flask, render_template, request, jsonify
import json
import os

from nlp_engine import AnswerValidator

app = Flask(__name__)
validator = AnswerValidator()

# ──────────────────────────────────────────────
# Sample Question Bank (editable)
# ──────────────────────────────────────────────
QUESTION_BANK = [
    {
        "id": 1,
        "subject": "Computer Networks",
        "topic": "IPv6",
        "question": "What is IPv6 and why was it introduced?",
        "model_answer": (
            "IPv6 (Internet Protocol version 6) is the most recent version of the Internet Protocol. "
            "It was introduced to address the exhaustion of IPv4 addresses. IPv4 uses 32-bit addresses "
            "providing about 4.3 billion addresses, which proved insufficient due to the rapid growth of "
            "the internet and connected devices. IPv6 uses 128-bit addresses, providing approximately "
            "340 undecillion unique addresses, ensuring scalability for future internet growth."
        ),
        "keywords": ["128-bit", "address exhaustion", "IPv4", "4.3 billion", "340 undecillion", "scalability"],
        "max_marks": 10
    },
    {
        "id": 2,
        "subject": "Database Management",
        "topic": "SQL",
        "question": "Explain the difference between DELETE, TRUNCATE, and DROP commands in SQL.",
        "model_answer": (
            "DELETE is a DML command that removes specific rows from a table based on a WHERE condition. "
            "It can be rolled back and fires triggers. TRUNCATE is a DDL command that removes all rows "
            "from a table at once; it is faster than DELETE, cannot be rolled back in most databases, "
            "and does not fire triggers. DROP is a DDL command that completely removes the table structure "
            "along with all its data and cannot be rolled back."
        ),
        "keywords": ["DML", "DDL", "rollback", "WHERE", "triggers", "table structure", "rows"],
        "max_marks": 10
    },
    {
        "id": 3,
        "subject": "Data Science",
        "topic": "Machine Learning",
        "question": "What is overfitting in machine learning and how can it be prevented?",
        "model_answer": (
            "Overfitting occurs when a machine learning model learns the training data too well, "
            "including its noise and random fluctuations, resulting in poor performance on unseen data. "
            "It can be prevented using techniques such as: regularization (L1/L2), dropout in neural "
            "networks, cross-validation, reducing model complexity, increasing training data size, "
            "and early stopping during training."
        ),
        "keywords": ["training data", "noise", "regularization", "dropout", "cross-validation", "generalization"],
        "max_marks": 10
    },
    {
        "id": 4,
        "subject": "Computer Networks",
        "topic": "OSI Model",
        "question": "Describe the OSI model and its seven layers.",
        "model_answer": (
            "The OSI (Open Systems Interconnection) model is a conceptual framework that standardizes "
            "network communication into seven layers: "
            "1. Physical Layer - transmits raw bits over physical medium. "
            "2. Data Link Layer - handles error detection and MAC addressing. "
            "3. Network Layer - responsible for IP addressing and routing. "
            "4. Transport Layer - provides end-to-end communication (TCP/UDP). "
            "5. Session Layer - manages sessions between applications. "
            "6. Presentation Layer - data translation, encryption, compression. "
            "7. Application Layer - user-facing protocols like HTTP, FTP, SMTP."
        ),
        "keywords": ["physical", "data link", "network", "transport", "session", "presentation", "application", "TCP", "routing"],
        "max_marks": 10
    },
    {
        "id": 5,
        "subject": "Database Management",
        "topic": "Normalization",
        "question": "What is database normalization? Explain 1NF, 2NF, and 3NF.",
        "model_answer": (
            "Database normalization is the process of organizing a database to reduce redundancy and "
            "improve data integrity. "
            "1NF (First Normal Form): A table is in 1NF if all columns contain atomic values and each "
            "column has a unique name with no repeating groups. "
            "2NF (Second Normal Form): A table is in 2NF if it is in 1NF and every non-key attribute "
            "is fully functionally dependent on the primary key (no partial dependency). "
            "3NF (Third Normal Form): A table is in 3NF if it is in 2NF and has no transitive "
            "dependencies — non-key attributes depend only on the primary key."
        ),
        "keywords": ["redundancy", "atomic", "1NF", "2NF", "3NF", "partial dependency", "transitive dependency", "primary key"],
        "max_marks": 10
    },
]


@app.route("/")
def index():
    return render_template("index.html", questions=QUESTION_BANK)


@app.route("/validate", methods=["POST"])
def validate():
    data = request.get_json()
    question_id = int(data.get("question_id", 0))
    student_answer = data.get("student_answer", "").strip()

    if not student_answer:
        return jsonify({"error": "Answer cannot be empty"}), 400

    # Find the question
    question = next((q for q in QUESTION_BANK if q["id"] == question_id), None)
    if not question:
        return jsonify({"error": "Question not found"}), 404

    # Run NLP validation
    result = validator.validate(
        student_answer=student_answer,
        model_answer=question["model_answer"],
        keywords=question["keywords"],
        max_marks=question["max_marks"]
    )

    result["question"] = question["question"]
    result["model_answer"] = question["model_answer"]
    return jsonify(result)


@app.route("/custom_validate", methods=["POST"])
def custom_validate():
    """Validate against a custom model answer (no predefined question needed)"""
    data = request.get_json()
    student_answer = data.get("student_answer", "").strip()
    model_answer = data.get("model_answer", "").strip()
    keywords_raw = data.get("keywords", "")
    max_marks = int(data.get("max_marks", 10))

    if not student_answer or not model_answer:
        return jsonify({"error": "Both answers required"}), 400

    keywords = [k.strip() for k in keywords_raw.split(",") if k.strip()]

    result = validator.validate(
        student_answer=student_answer,
        model_answer=model_answer,
        keywords=keywords,
        max_marks=max_marks
    )
    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
