import kagglehub
import pandas as pd
import re
import glob
import os
from sentence_transformers import SentenceTransformer
import faiss
from flask import Flask, render_template, request

app = Flask(__name__)

print("Downloading/Locating dataset via KaggleHub...")
path = kagglehub.dataset_download("rasikhali12/lk-hadith-corpus")
print(f"Dataset path: {path}")

all_csv_files = glob.glob(os.path.join(path, "**", "*.csv"), recursive=True)
print(f"Found {len(all_csv_files)} CSV files.")

dataframes = []
for file in all_csv_files:
    try:
        df_temp = pd.read_csv(file)
        
        if 'English_Hadith' in df_temp.columns:
            df_temp = df_temp.dropna(subset=['English_Hadith'])
            dataframes.append(df_temp)
    except Exception as e:
        print(f"Skipped file {file} due to error: {e}")

if not dataframes:
    print("\n--- ERROR DIAGNOSTICS ---")
    if len(all_csv_files) > 0:
        sample_df = pd.read_csv(all_csv_files[0])
        print(f"Found files, but 'English_Hadith' column is missing.")
        print(f"Actual columns in {os.path.basename(all_csv_files[0])}: {sample_df.columns.tolist()}")
    else:
        print("No CSV files were found in the downloaded folder at all.")
    raise ValueError("No data to process. Check the terminal output above to see the actual column names in the dataset.")

print("Data loaded successfully. Processing embeddings...")

df = pd.concat(dataframes, ignore_index=True)

def clean_text(text):
    if isinstance(text, str):
        text = re.sub(r'[^A-Za-z\s]', '', text)
        text = text.lower()
    else:
        text = ""
    return text

df['Cleaned_Text'] = df['English_Hadith'].apply(clean_text)

model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
embeddings = model.encode(df['Cleaned_Text'].tolist())

d = embeddings.shape[1]
index = faiss.IndexFlatL2(d)
index.add(embeddings)
faiss.write_index(index, 'hadith_faiss_en.index')
print("Backend is ready! Starting server...")

def retrieve_similar_data(query, k=5):
    cleaned_query = clean_text(query)
    query_embedding = model.encode([cleaned_query])
    distances, indices = index.search(query_embedding, k)
    
    results = []
    for i in range(k):
        text_result = df['English_Hadith'].iloc[indices[0][i]]
        dist = distances[0][i]
        results.append({'text': text_result, 'distance': round(float(dist), 4)})
        
    return results

@app.route('/', methods=['GET', 'POST'])
def index_page():
    search_results = []
    user_query = ""
    
    if request.method == 'POST':
        user_query = request.form['query']
        if user_query != "":
            search_results = retrieve_similar_data(user_query)
            
    return render_template('index.html', results=search_results, query=user_query)

if __name__ == '__main__':
    app.run(debug=True)