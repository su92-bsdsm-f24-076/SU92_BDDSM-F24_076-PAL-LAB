# Punctuation Removal Project (NLP + Flask)

## Features
- Removes punctuation from text
- Simple NLP preprocessing step
- Web interface using Flask

## How to Run
1. Install requirements:
   pip install -r requirements.txt

2. Run app:
   python app.py

3. Open browser:
   http://127.0.0.1:5000
