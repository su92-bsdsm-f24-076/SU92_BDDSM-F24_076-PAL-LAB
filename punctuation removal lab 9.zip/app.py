from flask import Flask, render_template, request
import string

app = Flask(__name__)

def remove_punctuation(text):
    return text.translate(str.maketrans('', '', string.punctuation))

@app.route('/', methods=['GET', 'POST'])
def index():
    result = ""
    if request.method == 'POST':
        text = request.form.get('text')
        result = remove_punctuation(text)
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
