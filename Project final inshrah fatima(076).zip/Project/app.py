from flask import Flask, render_template, request, jsonify
import json
import os

app = Flask(__name__)

DATA_FILE = os.path.join(app.root_path, 'questions.json')

def load_data():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, 'r') as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def calculate_similarity(user_ans, reference_ans):
    user_clean = user_ans.lower().replace('.', '').replace(',', '').replace('?', '')
    ref_clean = reference_ans.lower().replace('.', '').replace(',', '').replace('?', '')

    user_words = user_clean.split()
    ref_words = ref_clean.split()

    stop_words = ['the', 'is', 'in', 'and', 'of', 'to', 'a', 'an', 'for', 'it', 'with', 'as', 'by', 'on', 'are', 'was', 'were']
    
    user_filtered = [w for w in user_words if w not in stop_words]
    ref_filtered = [w for w in ref_words if w not in stop_words]

    match_count = 0
    ref_copy = list(ref_filtered)
    
    for word in user_filtered:
        if word in ref_copy:
            match_count += 1
            ref_copy.remove(word)

    total_important_words = len(ref_filtered)
    if total_important_words == 0:
        return 0
    
    score = (match_count / total_important_words) * 100
    return round(score, 2)


@app.route('/')
def home():
    questions = load_data()
    return render_template('index.html', questions=questions)

@app.route('/add_qa', methods=['POST'])
def add_qa():
    data = request.get_json()
    question = data.get('question')
    answer = data.get('answer')
    
    if question and answer:
        questions = load_data()
        new_q = {
            "id": len(questions) + 1,
            "question": question,
            "answer": answer
        }
        questions.append(new_q)
        save_data(questions)
        return jsonify({"status": "success", "data": new_q})
    return jsonify({"status": "error", "message": "Incomplete data"})

@app.route('/verify', methods=['POST'])
def verify():
    data = request.get_json()
    q_id = int(data.get('q_id'))
    user_ans = data.get('user_answer')

    questions = load_data()
    reference_ans = ""
    for q in questions:
        if q['id'] == q_id:
            reference_ans = q['answer']
            break
            
    if not reference_ans:
        return jsonify({"status": "error", "message": "Question not found"})

    score = calculate_similarity(user_ans, reference_ans)
    
    if score >= 60:
        feedback = "Correct Answer! Good Job."
        color = "#00d2ff"
    else:
        feedback = "Incorrect Answer. Please try again."
        color = "#ff4b4b"

    return jsonify({
        "status": "success", 
        "score": score, 
        "feedback": feedback,
        "color": color,
        "correct_answer": reference_ans
    })

if __name__ == '__main__':
    app.run(debug=True)